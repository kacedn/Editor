﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Cesa.SortPlanEditor.Dtos
{
    public class PhysicalOutputAssignmentDto : ViewModelBase
    {
        public PhysicalOutputAssignmentDto(int nbRepartition = 0)
        {
            OutputPoolList = new ObservableCollection<PhysicalOutputAssignmentDto>();
            this.nbRepartition = nbRepartition;
        }

        private PoolType poolType;
        public PoolType PoolType
        {
            get { return poolType; }
            set
            {
                poolType = value;
                OnPoolTypeChanged();
                RaisePropertyChanged();
            }
        }

        private void OnPoolTypeChanged()
        {
            if (PoolType != null && PoolType.Value == "physicalOutput")
            {
                PhysicalOutput = null;
                OutputPoolList.Clear();
                NbRepartition = 0;
            }
            else if (PoolType != null)
            {
                PhysicalOutput = null;
                foreach (var p in OutputPoolList)
                {
                    p.PoolTypes = GetFilteredPoolTypes(this.AllPoolTypes, PoolType);
                }
            }
        }

        private int? physicalOutput;
        public int? PhysicalOutput
        {
            get { return physicalOutput; }
            set
            {
                physicalOutput = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<PoolType> AllPoolTypes { get; set; }

        private ObservableCollection<PoolType> _PoolTypes;
        public ObservableCollection<PoolType> PoolTypes
        {
            get { return _PoolTypes; }
            set
            {
                _PoolTypes = value;
                RaisePropertyChanged();
            }
        }

        private bool isPrefrered;
        public bool IsPrefered
        {
            get { return isPrefrered; }
            set
            {
                isPrefrered = value;
                RaisePropertyChanged();
            }
        }

        public int nbRepartition;
        public int NbRepartition
        {
            get { return nbRepartition; }
            set
            {
                nbRepartition = value;
                RaisePropertyChanged();
                ComputeOutpoolListFromNbRepartition();
            }
        }

        private void ComputeOutpoolListFromNbRepartition()
        {
            if (nbRepartition <= 0)
            {
                OutputPoolList.Clear();
            }
            else
            {
                int actualCount = OutputPoolList.Count;
                if (nbRepartition > actualCount)
                {
                    for (int i = 0; i < nbRepartition - actualCount; i++)
                    {
                        OutputPoolList.Add(new PhysicalOutputAssignmentDto() { Parent = this, AllPoolTypes = this.AllPoolTypes, PoolTypes = GetFilteredPoolTypes(this.AllPoolTypes, this.PoolType), PoolType = PoolTypes?.FirstOrDefault(c => c.Value == "physicalOutput") });
                    }
                }
                else if (nbRepartition < actualCount)
                {
                    for (int i = actualCount - 1; i >= nbRepartition; i--)
                    {
                        OutputPoolList.RemoveAt(i);
                    }
                }
            }
        }

        public static ObservableCollection<PoolType> GetFilteredPoolTypes(ObservableCollection<PoolType>  poolTypes, PoolType parentPoolType)
        {
            if (poolTypes == null)
                return new ObservableCollection<PoolType>();

            if (parentPoolType != null)
            {
                switch (parentPoolType.Value)
                {
                    case "overflow":
                    case "loadBalancing":
                        return new ObservableCollection<PoolType>(poolTypes.Where(c => c.Value != "overflow" && c.Value != "loadBalancing" && c.Value != "duplication"));
                    case "duplication":
                        return new ObservableCollection<PoolType>(poolTypes.Where(c => c.Value != "duplication"));
                    default:
                        return poolTypes;
                }
            }
            else
            {
                return poolTypes;
            }
            
        }

        private ICommand _setAsPreferedCommand;
        public ICommand SetAsPreferedCommand
        {
            get
            {
                return _setAsPreferedCommand ?? (_setAsPreferedCommand = new RelayCommand(
                   () => {
                       if (Parent != null && Parent.OutputPoolList != null)
                       {
                           foreach (var pooltype in Parent.OutputPoolList)
                           {
                               pooltype.IsPrefered = false;
                           }
                       }
                       IsPrefered = true;
                   }));
            }
        }

        private ICommand _incrementVersionCommand;
        public ICommand IncrementVersionCommand
        {
            get
            {
                return _incrementVersionCommand ?? (_incrementVersionCommand = new RelayCommand(
                   () => {
                       NbRepartition++;
                   }));
            }
        }



        private ICommand _decrementVersionCommand;
        public ICommand DecrementVersionCommand
        {
            get
            {
                return _decrementVersionCommand ?? (_decrementVersionCommand = new RelayCommand(
                   () => {
                       if (NbRepartition > 1)
                       {
                           NbRepartition--;
                       }
                   }));
            }
        }

        public PhysicalOutputAssignmentDto Parent { get; set; }

        public ObservableCollection<PhysicalOutputAssignmentDto> OutputPoolList { get; set; }

    }
}
