﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Dtos
{
    public class RootSortPlan : ViewModelBase
    {
        public RootSortPlan()
        {
            HeaderDto = new HeaderDto();
            LogicalExitAssignments = new ObservableCollection<LogicalExitAssignmentDto>();
            LogicalDestinationOutputs = new ObservableCollection<LogicalDestinationOutputDto>();
            PhysicalRejectAssignments = new ObservableCollection<PhysicalRejectAssignmentDto>();
        }


        private HeaderDto headerDto;
        public HeaderDto HeaderDto
        {
            get { return headerDto; }
            set { headerDto = value; }
        }

        public ObservableCollection<LogicalExitAssignmentDto> LogicalExitAssignments { get; set; }
        public ObservableCollection<LogicalDestinationOutputDto> LogicalDestinationOutputs { get; set; }
        public ObservableCollection<PhysicalRejectAssignmentDto> PhysicalRejectAssignments { get; set; }


        public void FillPhysicalOutputLabel()
        {
            foreach (var ass in LogicalExitAssignments)
            {
                string fullLabel = null;
                fullLabel = $"{ass.PhysicalOutputAssignmentDto.PoolType.Label} : [";
                FillPhysicalOutputLabelRecursive(ass.PhysicalOutputAssignmentDto, ref fullLabel, ass.PhysicalOutputAssignmentDto.OutputPoolList.Count == 0);
                fullLabel += $"]";
                ass.PhysicalOutputLabel = fullLabel;
            }
        }

        private void FillPhysicalOutputLabelRecursive(PhysicalOutputAssignmentDto ass, ref string label, bool isLast = false)
        {
            if (ass.OutputPoolList.Count > 0)
            {
                for (int i = 0; i < ass.OutputPoolList.Count; i++)
                {
                    var phy = ass.OutputPoolList[i];
                    isLast = i == ass.OutputPoolList.Count - 1;
                    if (phy.OutputPoolList.Count > 0)
                    {
                        label += $"[{phy.PoolType.Label} : ";
                        FillPhysicalOutputLabelRecursive(phy, ref label, isLast);
                        label += $"]";
                        if (!isLast)
                        {
                            label += ", ";
                        }
                    }
                    else
                    {
                        FillPhysicalOutputLabelRecursive(phy, ref label, isLast);
                    }
                }
            }
            else
            {
                label += $"{ass.PhysicalOutput}";
                if (!isLast)
                {
                    label += ", ";
                }
            }
        }
    }
}
