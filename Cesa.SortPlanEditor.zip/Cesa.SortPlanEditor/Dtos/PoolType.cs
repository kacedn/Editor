﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Dtos
{
    public class PoolType : ViewModelBase
    {
        private string label;
        public string Label
        {
            get { return label; }
            set { label = value; RaisePropertyChanged(); }
        }

        private string val;
        public string Value
        {
            get { return val; }
            set { val = value; RaisePropertyChanged(); }
        }

    }
}
