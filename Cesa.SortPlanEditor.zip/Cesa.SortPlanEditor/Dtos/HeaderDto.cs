﻿using Cesa.SortPlanEditor.Messages;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cesa.SortPlanEditor.Dtos
{
    public class HeaderDto : ViewModelBase
    {
        public HeaderDto()
        {
            Created = DateTime.Now;
        }

        private string _alias;
        public string Alias
        {
            get { return _alias; }
            set { _alias = value; RaisePropertyChanged(); }
        }

        private string _label;
        public string Label
        {
            get { return _label; }
            set { _label = value; RaisePropertyChanged(); }
        }


        private int _version;
        public int Version
        {
            get { return _version; }
            set { _version = value; RaisePropertyChanged(); }
        }

        private DateTime _created;
        public DateTime Created
        {
            get { return _created; }
            set { _created = value; RaisePropertyChanged(); }
        }

        private DateTime? _updated;
        public DateTime? Updated
        {
            get { return _updated; }
            set { _updated = value; RaisePropertyChanged(); }
        }

        private string _modifiedBy;
        public string ModifiedBy
        {
            get { return _modifiedBy; }
            set { _modifiedBy = value; RaisePropertyChanged(); }
        }

        private int _parcelProcessingSystemId;
        public int ParcelProcessingSystemId
        {
            get { return _parcelProcessingSystemId; }
            set {
                _parcelProcessingSystemId = value;
                //Messenger.Default.Send(new ProcessingSystemChanged());
                RaisePropertyChanged();
            }
        }

        private string _launchingApproval;
        public string LaunchingApproval
        {
            get { return _launchingApproval; }
            set { if (string.IsNullOrEmpty(value)) { _launchingApproval = null; } RaisePropertyChanged(); }
        }

        private DateTime? _launchingApprovalDate;
        public DateTime? LaunchingApprovalDate
        {
            get { return _launchingApprovalDate; }
            set {
                _launchingApprovalDate = value;
                if (value != null && value != (default(DateTime)))
                {
                    _launchingApproval = value.Value.ToString("yyyy-MM-dd") ;
                }
                else
                {
                    LaunchingApproval = null;
                }
                RaisePropertyChanged(); }
        }

    }
}
