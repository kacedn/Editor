﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Serialization;

namespace Cesa.SortPlanEditor.Dtos
{
    public class LogicalExitAssignmentDto : ViewModelBase
    {
        public LogicalExitAssignmentDto()
        {
            ModifyValidateLabel = "Modifier";
        }

        private string logicalOutput;
        public string LogicalOutput
        {
            get { return logicalOutput; }
            set { logicalOutput = value; RaisePropertyChanged(); }
        }

        private PhysicalOutputAssignmentDto physicalOutputAssignmentDto;
        public PhysicalOutputAssignmentDto PhysicalOutputAssignmentDto
        {
            get { return physicalOutputAssignmentDto; }
            set { physicalOutputAssignmentDto = value; RaisePropertyChanged(); }
        }

        private PhysicalOutputAssignmentDto physicalOutputAssignmentDtoBinding;
        public PhysicalOutputAssignmentDto PhysicalOutputAssignmentDtoBinding
        {
            get { return physicalOutputAssignmentDtoBinding; }
            set { physicalOutputAssignmentDtoBinding = value; RaisePropertyChanged(); }
        }

        private string physicalOutputLabel;
        public string PhysicalOutputLabel
        {
            get { return physicalOutputLabel; }
            set { physicalOutputLabel = value; RaisePropertyChanged(); }
        }


        private bool inModification;
        public bool InModification
        {
            get { return inModification && RightsManager.CanWrite; }
            set { inModification = value; RaisePropertyChanged(); }
        }

        private string _ModifyValidateLabel;
        public string ModifyValidateLabel
        {
            get { return _ModifyValidateLabel; }
            set { _ModifyValidateLabel = value; RaisePropertyChanged(); }
        }



        private ICommand _ModifyValidateCommand;
        public ICommand ModifyValidateCommand
        {
            get
            {
                return _ModifyValidateCommand ?? (_ModifyValidateCommand = new RelayCommand(
                   () => {
                       if (InModification)
                       {
                           InModification = false;
                           ModifyValidateLabel = "Modifier";
                           this.PhysicalOutputAssignmentDto = new PhysicalOutputAssignmentDto()
                           {
                               AllPoolTypes = this.PhysicalOutputAssignmentDtoBinding.AllPoolTypes,
                               PoolType = this.PhysicalOutputAssignmentDtoBinding.PoolType,
                               IsPrefered = this.PhysicalOutputAssignmentDtoBinding.IsPrefered,
                               nbRepartition = this.PhysicalOutputAssignmentDtoBinding.NbRepartition,
                               PhysicalOutput = this.PhysicalOutputAssignmentDtoBinding.PhysicalOutput,
                               Parent = this.PhysicalOutputAssignmentDtoBinding.Parent,
                               PoolTypes = this.PhysicalOutputAssignmentDtoBinding.PoolTypes
                           };
                           AssignOutputRecusively(this.physicalOutputAssignmentDtoBinding.OutputPoolList, this.physicalOutputAssignmentDto.OutputPoolList);
                       }
                       else
                       {
                           InModification = true;
                           ModifyValidateLabel = "Valider";
                       }
                   }));
            }
        }

        public void AssignOutputRecusively(ObservableCollection<PhysicalOutputAssignmentDto> assignmentsDto, ObservableCollection<PhysicalOutputAssignmentDto> assignemnts)
        {
            if (assignmentsDto != null)
            {
                foreach (var assignment in assignmentsDto)
                {
                    var physOutput = new PhysicalOutputAssignmentDto()
                    {
                        AllPoolTypes = assignment.AllPoolTypes,
                        PoolType = assignment.PoolType,
                        IsPrefered = assignment.IsPrefered,
                        nbRepartition = assignment.NbRepartition,
                        PhysicalOutput = assignment.PhysicalOutput,
                        Parent = assignment.Parent,
                        PoolTypes = assignment.PoolTypes
                    };
                    assignemnts.Add(physOutput);
                    AssignOutputRecusively(assignment.OutputPoolList, physOutput.OutputPoolList);
                }
            }
        }

        private ICommand _cancelModifyCommand;
        public ICommand CancelModifyCommand
        {
            get
            {
                return _cancelModifyCommand ?? (_cancelModifyCommand = new RelayCommand(
                   () => {

                       InModification = false;
                       ModifyValidateLabel = "Modifier";
                       this.PhysicalOutputAssignmentDtoBinding = new PhysicalOutputAssignmentDto()
                       {
                           AllPoolTypes = this.PhysicalOutputAssignmentDto.AllPoolTypes,
                           IsPrefered = this.PhysicalOutputAssignmentDto.IsPrefered,
                           nbRepartition = this.PhysicalOutputAssignmentDto.NbRepartition,
                           PhysicalOutput = this.PhysicalOutputAssignmentDto.PhysicalOutput,
                           Parent = this.PhysicalOutputAssignmentDto.Parent,
                           PoolType = this.PhysicalOutputAssignmentDto.PoolType,
                           PoolTypes = this.PhysicalOutputAssignmentDto.PoolTypes
                       };

                       AssignOutputRecusively(this.physicalOutputAssignmentDto.OutputPoolList, this.PhysicalOutputAssignmentDtoBinding.OutputPoolList);
                   }));
            }
        }

    }
}
