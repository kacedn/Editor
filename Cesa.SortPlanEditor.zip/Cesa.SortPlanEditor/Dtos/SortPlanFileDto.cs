﻿using Cesa.SortPlanEditor.Helpers;
using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Dtos
{
    public class SortPlanFileDto : ViewModelBase
    {
        public SortPlanFileDto()
        {
            RootSortPlan = new RootSortPlan();
        }

        private RootSortPlan _rootSortPlan;
        public RootSortPlan RootSortPlan
        {
            get { return _rootSortPlan; }
            set { _rootSortPlan = value; RaisePropertyChanged(); }
        }

        public string FilePath { get; set; }

        private bool _isNew;
        public bool IsNew
        {
            get { return _isNew; }
            set { _isNew = value; RaisePropertyChanged(); }
        }

        private bool _isLocked;
        public bool IsLocked
        {
            get { return _isLocked; }
            set { _isLocked = value; RaisePropertyChanged(); }
        }

        private string _lockedBy;
        public string LockedBy
        {
            get { return _lockedBy; }
            set { _lockedBy = value; RaisePropertyChanged(); }
        }
    }
}
