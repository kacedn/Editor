﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Dtos
{
    public class RejectType
    {
        public string SortPlanLabel { get; set; }
        public string DisplayLabel { get; set; }
    }
}
