﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Cesa.SortPlanEditor.Dtos
{
    public class PhysicalRejectAssignmentDto : ViewModelBase
    {
        public PhysicalRejectAssignmentDto()
        {
            StatusBinding = new ObservableCollection<string>();
            Status = new ObservableCollection<string>();
            InModification = false;
        }

        public void RefreshStatusLabel()
        {
            if (Status != null)
            {
                StatusLabel = string.Join(", ", StatusBinding);
            }
        }

        private string rejectLabel;
        public string RejectLabel
        {
            get { return rejectLabel; }
            set
            {
                rejectLabel = value;
                RaisePropertyChanged();
            }
        }

        private RejectType rejectTypeBinding;
        public RejectType RejectTypeBinding
        {
            get { return rejectTypeBinding; }
            set
            {
                bool canChangeOutput = false;
                if (rejectTypeBinding != null && rejectTypeBinding.SortPlanLabel == LogicalOutput)
                {
                    canChangeOutput = true;
                }
                rejectTypeBinding = value;
                RaisePropertyChanged();
                RejectLabel = value?.SortPlanLabel;
                if (canChangeOutput)
                {
                    LogicalOutput = value?.SortPlanLabel;
                }
            }
        }

        private RejectType rejectType;
        public RejectType RejectType
        {
            get { return rejectType; }
            set
            {
                rejectType = value;
                rejectTypeBinding = value;
                RaisePropertyChanged();
            }
        }

        private string logicalOutput;
        public string LogicalOutput
        {
            get { return logicalOutput; }
            set { logicalOutput = value; logicalOutputBinding = value; RaisePropertyChanged(); }
        }

        private string logicalOutputBinding;
        public string LogicalOutputBinding
        {
            get { return logicalOutputBinding; }
            set { logicalOutputBinding = value; RaisePropertyChanged(); }
        }

        private int index;
        public int Index
        {
            get { return index; }
            set { index = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<string> status;
        public ObservableCollection<string> Status
        {
            get { return status; }
            set
            {
                status = value;
                if (value != null)
                {
                    StatusBinding.Clear();
                    foreach (var s in value)
                    {
                        StatusBinding.Add(s);
                    }
                }
                RaisePropertyChanged();
            }
        }

        private ObservableCollection<string> statusBinding;
        public ObservableCollection<string> StatusBinding
        {
            get { return statusBinding; }
            set { statusBinding = value; RaisePropertyChanged(); }
        }

        private string selectedStatus;

        public string SelectedStatus
        {
            get { return selectedStatus; }
            set { selectedStatus = value; RaisePropertyChanged(); }
        }


        private string statusLabel;
        public string StatusLabel
        {
            get { return statusLabel; }
            set { statusLabel = value; RaisePropertyChanged(); }
        }


        private bool inModification;
        public bool InModification
        {
            get { return inModification && RightsManager.CanWrite; }
            set
            {
                inModification = value;
                if (inModification)
                {
                    ModifyValidateLabel = "Valider";
                }
                else
                {
                    ModifyValidateLabel = "Modifier";
                }
                RaisePropertyChanged();
            }
        }

        private string _ModifyValidateLabel;
        public string ModifyValidateLabel
        {
            get { return _ModifyValidateLabel; }
            set { _ModifyValidateLabel = value; RaisePropertyChanged(); }
        }



        private ICommand _ModifyValidateCommand;
        public ICommand ModifyValidateCommand
        {
            get
            {
                return _ModifyValidateCommand ?? (_ModifyValidateCommand = new RelayCommand(
                   () => {
                       if (InModification)
                       {
                           InModification = false;
                           this.RejectType = RejectTypeBinding;
                           this.LogicalOutput = LogicalOutputBinding;
                           Status.Clear();
                           foreach (var s in StatusBinding)
                           {
                               Status.Add(s);
                           }
                       }
                       else
                       {
                           InModification = true;
                       }
                   }));
            }
        }

        private ICommand _cancelModifyCommand;
        public ICommand CancelModifyCommand
        {
            get
            {
                return _cancelModifyCommand ?? (_cancelModifyCommand = new RelayCommand(
                   () => {

                       InModification = false;
                       this.RejectTypeBinding = RejectType;
                       this.LogicalOutputBinding = LogicalOutput;
                       StatusBinding.Clear();
                       foreach (var s in Status)
                       {
                           StatusBinding.Add(s);
                       }
                       RefreshStatusLabel();
                   }));
            }
        }

    }
}
