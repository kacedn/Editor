﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Dtos
{
    public class LoginResult
    {
        public bool IsLoginValid { get; set; }
        public bool IsAllowed { get; set; }
        public bool HasReadOnlyAccess { get; set; }
        public string UserFullName { get; set; }
    }
}
