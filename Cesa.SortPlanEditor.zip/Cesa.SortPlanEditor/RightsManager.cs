﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor
{
    public class RightsManager
    {
        private static bool canWrite;
        public static bool CanWrite
        {
            get
            {
                return canWrite;
            }

            set
            {
                canWrite = value;
                OnCanWriteChanged(EventArgs.Empty);
            }
        }


        private static string fullname;
        public static string Fullname
        {
            get
            {
                return fullname;
            }

            set
            {
                fullname = value;
                OnFullnameChanged(EventArgs.Empty);
            }
        }

        public static event EventHandler CanWriteChanged;
        protected static void OnCanWriteChanged(EventArgs e)
        {
            EventHandler handler = CanWriteChanged;

            if (handler != null)
            {
                handler(null, e);
            }
        }

        public static event EventHandler CanWriteAndNoFilterChanged;
        protected static void OnCanWriteAndNoFilterChanged(EventArgs e)
        {
            EventHandler handler = CanWriteAndNoFilterChanged;

            if (handler != null)
            {
                handler(null, e);
            }
        }

        public static event EventHandler FullnameChanged;
        protected static void OnFullnameChanged(EventArgs e)
        {
            EventHandler handler = FullnameChanged;

            if (handler != null)
            {
                handler(null, e);
            }
        }

   

    }
}
