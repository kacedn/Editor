﻿using Cesa.SortPlanEditor.Converters;
using Cesa.SortPlanEditor.Helpers;
using Cesa.SortPlanEditor.ViewModels;
using Cesa.SortPlanEditor.Views;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace Cesa.SortPlanEditor
{
    public class MainWindowVM : LoadableVM
    {

        public MainWindowVM()
        {
            NavigationHelper.MainWindowVM = this;
            RightsManager.Fullname = "Invité";

            this.ConfigViewVM = new ConfigViewVM();
            this.ConfigViewVM.Load(this);

            NavigateCommand = new RelayCommand<ViewSelection>(ExecuteNavigate);
            Refresh = new RelayCommand(ExecuteRefresh);
            LoginCommand = new RelayCommand(Login);
            ValidAuthCommand = new RelayCommand<PasswordBox>((p) => ValidAuth(p));
            CancelAuthCommand = new RelayCommand(CancelAuth);
            this.ExecuteNavigate(new ViewSelection() { ViewName = NavigationHelper.HOME_VIEW });



            this.LastRefreshDateTime = DateTime.Now;
            Timer = new DispatcherTimer(); DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(1000);
            Timer.Tick += Timer_Tick;
            Timer.Start();
        }

  

        #region Cache
        public ConfigViewVM ConfigViewVM { get; set; }
        #endregion

        public RelayCommand<ViewSelection> NavigateCommand { get; set; }
        public RelayCommand Refresh { get; set; }
        public RelayCommand RemoveFilters { get; set; }
        public RelayCommand LoginCommand { get; set; }
        public RelayCommand<PasswordBox> ValidAuthCommand { get; set; }
        public RelayCommand CancelAuthCommand { get; set; }

        private readonly object _lock = new object();
        public DispatcherTimer Timer { get; set; }

        private bool filtersAreVisible;
        public bool FiltersAreVisible
        {
            get { return filtersAreVisible; }
            set { filtersAreVisible = value; RaisePropertyChanged(); }
        }

        private ICommand _toggleFiltersCommand;
        public ICommand ToggleFiltersCommand
        {
            get
            {
                return _toggleFiltersCommand ?? (_toggleFiltersCommand = new RelayCommand(
                   () => {
                       FiltersAreVisible = !FiltersAreVisible;
                   }));
            }
        }

        private DateTime _lastRefreshDateTime { get; set; }
        public DateTime LastRefreshDateTime
        {
            get
            {
                return _lastRefreshDateTime;
            }
            set
            {
                _lastRefreshDateTime = value;
                RaisePropertyChanged();
            }
        }

        private DateTime _currentDateTime { get; set; }
        public DateTime CurrentDateTime
        {
            get { return _currentDateTime; }
            set { _currentDateTime = value; RaisePropertyChanged(); }
        }

        private string _nextRefresh { get; set; }
        public string NextRefresh
        {
            get { return _nextRefresh; }
            set { _nextRefresh = value; RaisePropertyChanged(); }
        }

        private string _username { get; set; }
        public string UserName
        {
            get { return _username; }
            set { _username = value; RaisePropertyChanged(); }
        }

        private ViewBaseVM _displayedVM { get; set; }
        public ViewBaseVM DisplayedVM
        {
            get { return _displayedVM; }
            set { _displayedVM = value; RaisePropertyChanged(); }
        }

        private string _currentContentName { get; set; }
        public string CurrentContentName
        {
            get { return _currentContentName; }
            set { _currentContentName = value; RaisePropertyChanged(); }
        }

        private FrameworkElement _displayedContent { get; set; }
        public FrameworkElement DisplayedContent
        {
            get { return _displayedContent; }
            set { _displayedContent = value; RaisePropertyChanged(); }
        }

        private FrameworkElement _displayedPopupContent { get; set; }
        public FrameworkElement DisplayedPopupContent
        {
            get { return _displayedPopupContent; }
            set { _displayedPopupContent = value; RaisePropertyChanged(); }
        }

        private bool _isWorking { get; set; }
        public bool IsWorking
        {
            get { return _isWorking; }
            set { _isWorking = value; RaisePropertyChanged(); }
        }

        private bool _isPopupVisible { get; set; }
        public bool IsPopupVisible
        {
            get { return _isPopupVisible; }
            set { _isPopupVisible = value; RaisePropertyChanged(); }
        }


        private Task RunInTask(Action a)
        {
            return Task.Run(() =>
            {
                IsWorking = true;
                a();
                IsWorking = false;
            });
        }

        public void ExecuteNavigate(ViewSelection viewSelection)
        {
            NavigationHelper.Navigate(viewSelection);
        }


        public void Login()
        {
            if (RightsManager.CanWrite)
            {
                var r = MessageBox.Show("Voulez-vous vous déconnecter ?", "Déconnexion", MessageBoxButton.YesNo);
                if (r == MessageBoxResult.Yes)
                {
                    RightsManager.CanWrite = false;
                    RightsManager.Fullname = "Invité";
                }
            }
            else
            {
                NavigationHelper.DisplayAuthPopup(this);
            }
        }


        public void ValidAuth(PasswordBox pw)
        {
            var result = DbHelper.Login(UserName, pw.Password);
            if (result != null && result.IsLoginValid)
            {
                RightsManager.CanWrite = result.IsAllowed && !result.HasReadOnlyAccess;
                RightsManager.Fullname = result.UserFullName;
            }
            else
            {
                RightsManager.CanWrite = false;
                RightsManager.Fullname = "Invité";
            }
            NavigationHelper.HidePopup(this);
        }

        public void CancelAuth()
        {
            NavigationHelper.HidePopup(this);
        }

        public void ExecuteRefresh()
        {
            lock (_lock)
            {
                try
                {
                    LastRefreshDateTime = DateTime.Now;
                    this.Load(this);
                }
                catch (Exception)
                {
                    //  Ignored
                }
            }
        }

        public override void Load(MainWindowVM mainVM)
        {
            if (!(this.DisplayedVM?.VM is SortPlanViewVM))
            {
                try
                {
                    Mouse.SetCursor(Cursors.Wait);
                    this.DisplayedVM?.Load(this);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
                finally
                {
                    Mouse.SetCursor(Cursors.Arrow);
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            CurrentDateTime = DateTime.Now;
            var elaspedTime = CurrentDateTime - this.LastRefreshDateTime;
            int val = 360;
            var refreshIn = val - Math.Round(elaspedTime.TotalSeconds, 0);
            if (refreshIn <= 0)
            {
                this.ExecuteRefresh();
            }
            else
            {
                NextRefresh = $"Prochain rafraichissement dans {refreshIn} s";
            }
        }

     
    }
}
