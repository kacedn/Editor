﻿using Cesa.SortPlanEditor.Helpers;
using Cesa.SortPlanEditor.Messages;
using Fluent;
using GalaSoft.MvvmLight.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ComboBox = System.Windows.Controls.ComboBox;
using TextBox = System.Windows.Controls.TextBox;

namespace Cesa.SortPlanEditor
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : RibbonWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainWindowVM();
            this.PreviewKeyDown += new KeyEventHandler(HandleEsc);

            EventManager.RegisterClassHandler(typeof(TextBox),
            TextBox.LostFocusEvent, new RoutedEventHandler(lostFocusTextbox));

            EventManager.RegisterClassHandler(typeof(ComboBox),
            ComboBox.LostFocusEvent, new RoutedEventHandler(lostFocusTextbox));
        }

        private void lostFocusTextbox(object sender, RoutedEventArgs args)
        {
            Messenger.Default.Send(new ChangeMessage());
        }

        private void HandleEsc(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
                NavigationHelper.HidePopup(this.DataContext as MainWindowVM);
        }
    }
}
