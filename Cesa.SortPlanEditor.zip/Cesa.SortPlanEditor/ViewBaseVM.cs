﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor
{
    public class ViewBaseVM  : LoadableVM
    {
        public LoadableVM VM { get; set; }

        public override void Load(MainWindowVM mainVM)
        {
            this.VM?.Load(mainVM);
        }
    }
}
