﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Cesa.SortPlanEditor.TemplateSelectors
{
    public class PoolTypeDataTemplateSelector : DataTemplateSelector
    {
        private DataTemplate repartitionDataTemplate;
        public DataTemplate RepartitionDataTemplate
        {
            get { return repartitionDataTemplate; }
            set { repartitionDataTemplate = value; }
        }

        private DataTemplate dedoublementDataTemplate;
        public DataTemplate DedoublementDataTemplate
        {
            get { return dedoublementDataTemplate; }
            set { dedoublementDataTemplate = value; }
        }

        private DataTemplate debordementDataTemplate;
        public DataTemplate DebordementDataTemplate
        {
            get { return debordementDataTemplate; }
            set { debordementDataTemplate = value; }
        }

        private DataTemplate sortiePhysiqueDataTemplate;
        public DataTemplate SortiePhysiqueDataTemplate
        {
            get { return sortiePhysiqueDataTemplate; }
            set { sortiePhysiqueDataTemplate = value; }
        }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            string poolType = item as string;
            switch (poolType)
            {
                case "physicalOutput":
                    {
                        return SortiePhysiqueDataTemplate;
                    }
                case "loadBalancing":
                case "duplication":
                case "overflow":
                    {
                        return RepartitionDataTemplate;
                    }
                default:
                    {
                        return new DataTemplate();
                    }
            }
        }

    }
}
