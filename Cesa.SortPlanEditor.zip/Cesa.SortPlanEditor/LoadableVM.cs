﻿using Cesa.SortPlanEditor.ViewModels;
using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor
{
    public class LoadableVM : ViewModelBase
    {
        public virtual void Load(MainWindowVM mainVM)
        {
        }

        public virtual void Unload()
        {
        }
    }
}
