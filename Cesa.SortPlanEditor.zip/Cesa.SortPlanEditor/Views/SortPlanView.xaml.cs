﻿using Cesa.SortPlanEditor.Dtos;
using Cesa.SortPlanEditor.ViewModels;
using Microsoft.Win32;
using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cesa.SortPlanEditor.Views
{
    /// <summary>
    /// Logique d'interaction pour SortPlanView.xaml
    /// </summary>
    public partial class SortPlanView : UserControl
    {
        public SortPlanView()
        {
            InitializeComponent();

            
        }

        private void SaveMenu_Click(object sender, RoutedEventArgs e)
        {
            (sender as Button).ContextMenu.IsEnabled = true;
            (sender as Button).ContextMenu.PlacementTarget = (sender as Button);
            (sender as Button).ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
            (sender as Button).ContextMenu.IsOpen = true;
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var dc = this.DataContext as SortPlanViewVM;
            if (dc != null)
            {
                dc.OnProcessingSystemSelectionChanged(e);
            }
        }

        private void TabItem_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var dc = this.DataContext as SortPlanViewVM;
            if (dc != null)
            {
                dc.OnPhysicalExitTabClicked(e);
            }
        }

        private void Filter_DG_LogOutputs_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox t = (TextBox)sender;
            string filter = t.Text;
            ICollectionView cv = CollectionViewSource.GetDefaultView(DG_LogOutputs.ItemsSource);
            AddLogicalButton.IsEnabled = RightsManager.CanWrite;
            if (filter == "")
                cv.Filter = null;
            else
            {
                
                cv.Filter = o =>
                {
                    LogicalDestinationOutputDto p = o as LogicalDestinationOutputDto;

                    if (t.Name == "TB_LogStatusLabel")
                        return (p?.Status != null && p.Status.Contains(filter));
                    else if (t.Name == "TB_DestLogLabel")
                        return (p?.LogicalDestination != null && p.LogicalDestination.Contains(filter));
                    else if (t.Name == "TB_LogLogicalLabel")
                        return (p?.LogicalOutput != null && p.LogicalOutput.Contains(filter));
                    return true;
                };

                AddLogicalButton.IsEnabled = false;
            }
        }

        private void Filter_DG_PhyOutputs_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox t = (TextBox)sender;
            string filter = t.Text;
            ICollectionView cv = CollectionViewSource.GetDefaultView(DG_PhyOutputs.ItemsSource);
            if (filter == "")
                cv.Filter = null;
            else
            {
                cv.Filter = o =>
                {
                    LogicalExitAssignmentDto p = o as LogicalExitAssignmentDto;
                    if (t.Name == "TB_LogicalExitAssignments")
                        return (p.LogicalOutput.Contains(filter));
                    else if (t.Name == "TB_PhysicalOutputLabel")
                        return (p.PhysicalOutputLabel.Contains(filter));
                    return true;
                };
            }
        }

        private void Filter_DG_Reject_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox t = (TextBox)sender;
            string filter = t.Text;
            ICollectionView cv = CollectionViewSource.GetDefaultView(DG_Reject.ItemsSource);
            AddRejectButton.IsEnabled = RightsManager.CanWrite;
            if (filter == "")
                cv.Filter = null;
            else
            {
                cv.Filter = o =>
                {
                    PhysicalRejectAssignmentDto p = o as PhysicalRejectAssignmentDto;
                    if (t.Name == "TB_StatusLabelReject")
                        return (p.StatusLabel.Contains(filter));
                    else if (t.Name == "TB_RejectLabelReject")
                        return (p.RejectLabel.Contains(filter));
                    else if (t.Name == "TB_OutputLabelReject")
                        return (p.LogicalOutput.Contains(filter));
                    return true;
                };
                AddRejectButton.IsEnabled = false;
            }
        }

        private void ListBox_Dest_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = this.DataContext as SortPlanViewVM;
            if (vm != null)
            {
                vm.AddStatusCommand.Execute(null);
            }
        }

        private void ListBox_DestAffected_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = this.DataContext as SortPlanViewVM;
            if (vm != null)
            {
                vm.RemoveStatusCommand.Execute(null);
            }
        }

        private void ListBox_Reject_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = this.DataContext as SortPlanViewVM;
            if (vm != null)
            {
                vm.AddStatusInRejectCommand.Execute(null);
            }
        }

        private void ListBox_RejectAffected_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = this.DataContext as SortPlanViewVM;
            if (vm != null)
            {
                vm.RemoveStatusInRejectCommand.Execute(null);
            }
        }
    }
}
