﻿using Cesa.SortPlanEditor.Dtos;
using Cesa.SortPlanEditor.Helpers;
using Cesa.SortPlanEditor.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cesa.SortPlanEditor.Views
{
    /// <summary>
    /// Logique d'interaction pour HomeView.xaml
    /// </summary>
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }

        private void TB_Label_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox t = (TextBox)sender;
            string filter = t.Text;
            ICollectionView cv = CollectionViewSource.GetDefaultView(DG_Home.ItemsSource);
            CreateButton.IsEnabled = RightsManager.CanWrite;
            if (filter == "")
            {
                cv.Filter = null;
            }
            else
            {
                cv.Filter = o =>
                {
                    SortPlanFileDto p = o as SortPlanFileDto;
                    if (t.Name == "TB_Label")
                        return  (p?.RootSortPlan?.HeaderDto?.Label != null && p.RootSortPlan.HeaderDto.Label.Contains(filter));
                    return true;
                };
                CreateButton.IsEnabled = false;
            }
        }

        private void Row_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = this.DataContext as HomeViewVM;
            if (vm != null)
            {
                NavigationHelper.Navigate(new Converters.ViewSelection() { ViewName = "HomeView", SubViewName = "SortPlanView" });
            }
        }
    }
}
