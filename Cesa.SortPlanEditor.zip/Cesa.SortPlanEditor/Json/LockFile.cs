﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Json
{
    public class LockFile
    {
        public DateTime Datetime { get; set; }
        public string LockedBy { get; set; }
    }
}
