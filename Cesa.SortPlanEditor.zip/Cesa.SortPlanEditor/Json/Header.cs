﻿using GalaSoft.MvvmLight;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cesa.SortPlanEditor.Json
{
    public class Header
    {
        public Header()
        {
            Version = 0;
        }

        [JsonProperty(PropertyName = "alias")]
        public string Alias { get; set; }

        [JsonProperty(PropertyName = "label")]
        public string Label { get; set; }

        [JsonProperty(PropertyName = "version")]
        [DefaultValue(-1)]
        public int Version { get; set; }

        [JsonProperty(PropertyName = "created")]
        public DateTime Created { get; set; }

        [JsonProperty(PropertyName = "updated")]
        public DateTime? Updated { get; set; }

        [JsonProperty(PropertyName = "modifiedBy")]
        public string ModifiedBy { get; set; }

        [JsonProperty(PropertyName = "parcelProcessingSystemId")]
        public int ParcelProcessingSystemId { get; set; }

        [JsonProperty(PropertyName = "launchingApproval")]
        public string LaunchingApproval { get; set; }

    }
}
