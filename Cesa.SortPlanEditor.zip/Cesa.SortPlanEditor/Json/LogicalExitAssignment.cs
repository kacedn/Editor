﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cesa.SortPlanEditor.Json
{
    public class LogicalExitAssignment
    {
        public LogicalExitAssignment()
        {
        }

        [JsonProperty(PropertyName = "logicalOutput")]
        public string LogicalOutput { get; set; }

        [JsonProperty(PropertyName = "physicalOutputAssignments")]
        public PhysicalOutputAssignment PhysicalOutputAssignments { get; set; }
    }
}
