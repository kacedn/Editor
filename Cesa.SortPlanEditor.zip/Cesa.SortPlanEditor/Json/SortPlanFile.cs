﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Json
{
    public class SortPlanFile
    {
        [JsonProperty(PropertyName = "sortPlan")]
        public SortPlan SortPlan { get; set; }
    }
}
