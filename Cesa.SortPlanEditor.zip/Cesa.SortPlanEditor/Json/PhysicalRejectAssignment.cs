﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cesa.SortPlanEditor.Json
{
    public class PhysicalRejectAssignment
    {
        [JsonProperty(PropertyName = "rejectTypeLabel")]
        public string PhysicalReject { get; set; }
        [JsonProperty(PropertyName = "logicalOutput")]
        public string LogicalOutput { get; set; }
        [JsonProperty(PropertyName = "index")]
        [DefaultValue(-1)]
        public int Index { get; set; }
        [JsonProperty(PropertyName = "status")]
        public List<string> Status { get; set; }

    }
}
