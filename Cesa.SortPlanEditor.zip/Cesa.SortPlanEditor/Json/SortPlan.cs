﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Json
{
    public class SortPlan
    {
        [JsonProperty(PropertyName = "header")]
        public Header Header { get; set; }
        [JsonProperty(PropertyName = "logicalOutputAssignments")]
        public List<LogicalExitAssignment> LogicalExitAssignments { get; set; }
        [JsonProperty(PropertyName = "logicalDestinationAssignments")]
        public List<LogicalDestinationAssignment> LogicalDestinationAssignments { get; set; }
        [JsonProperty(PropertyName = "rejectAssignments")]
        public List<PhysicalRejectAssignment> PhysicalRejectAssignments { get; set; }
    }
}
