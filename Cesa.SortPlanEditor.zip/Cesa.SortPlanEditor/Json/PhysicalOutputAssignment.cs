﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Json
{
    public class PhysicalOutputAssignment
    {
        public PhysicalOutputAssignment()
        {
            OutputPoolList = new List<PhysicalOutputAssignment>();
        }

        [JsonProperty(PropertyName = "physicalOutput")]
        public int? PhysicalOutput { get; set; }
        [JsonProperty(PropertyName = "isPreferred")]
        public bool IsPrefered { get; set; }
        [JsonProperty(PropertyName = "poolType")]
        public string PoolType { get; set; }
        [JsonProperty(PropertyName = "outputPoolList")]
        public List<PhysicalOutputAssignment> OutputPoolList { get; set; }
    }
}
