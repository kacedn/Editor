﻿using Cesa.SortPlanEditor.Dtos;
using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Cesa.SortPlanEditor.Helpers
{
    public class DbHelper
    {
        public static LoginResult Login(string username, string password)
        {
            LoginResult result = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductionConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_UserLogin";
                    var values = new { Username = username, Password = password };
                    result = connection.Query<LoginResult>(procedure, values, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return result;
        }

        public static List<ProcessingSystem> GetProcessingSystems()
        {
            List<ProcessingSystem> result = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefinitionOPBConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_GetParcelProcessingSystems";
                    result = connection.Query<ProcessingSystem>(procedure, commandType: CommandType.StoredProcedure).ToList();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return result;
        }

        public static List<string> GetLogicalDestinations(int? idPPS)
        {
            List<string> result = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductionConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_GetLogicalDestinations";
                    var values = new { IdPPS = idPPS };
                    result = connection.Query<string>(procedure, values, commandType: CommandType.StoredProcedure).ToList();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return result;
        }

        public static List<RejectType> GetRejectTypes()
        {
            List<RejectType> result = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductionConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_GetRejectTypes";
                    result = connection.Query<RejectType>(procedure, commandType: CommandType.StoredProcedure).ToList();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return result;
        }

        public static string GetSortPlanFolder(string machineName)
        {
            string result = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductionConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_GetParameters";
                    var values = new { MachineName = machineName };
                    result = connection.Query<string>(procedure, values, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return result;
        }

        public static void SetSortPlanFolder(string machineName, string path)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductionConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_SetParameters";
                    var values = new { MachineName = machineName, SortPlanFolder = path };
                    connection.Execute(procedure, values, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            
        }

        public static List<Status> GetStatusList(int? idPPS)
        {
            List<Status> result = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductionConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_GetStatusList";
                    var values = new { IdPPS = idPPS };
                    result = connection.Query<Status>(procedure, values, commandType: CommandType.StoredProcedure).ToList();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return result;
        }

        public static List<PhysicalOutput> GetPhysicalOutputs(int idPPS)
        {
            List<PhysicalOutput> result = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefinitionOPBConnectionString"].ConnectionString))
                {
                    var procedure = "SortPlanEditor_GetPhysicalOutputs";
                    var values = new { IdPPS = idPPS };
                    result = connection.Query<PhysicalOutput>(procedure, values, commandType: CommandType.StoredProcedure).ToList();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return result;
        }
    }
}
