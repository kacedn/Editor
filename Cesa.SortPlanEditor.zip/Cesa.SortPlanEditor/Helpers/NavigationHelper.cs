﻿using Cesa.SortPlanEditor.Converters;
using Cesa.SortPlanEditor.Dtos;
using Cesa.SortPlanEditor.Popups;
using Cesa.SortPlanEditor.ViewModels;
using Cesa.SortPlanEditor.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Cesa.SortPlanEditor.Helpers
{
    public class NavigationHelper
    {
        public const string HOME_VIEW = "HomeView";
        public const string CONFIG_VIEW = "ConfigView";
        public const string SORT_PLAN_VIEW = "SortPlanView";

        public static MainWindowVM MainWindowVM { get; set; }

        public static void Navigate(ViewSelection viewSelection)
        {
            try
            {
                Mouse.SetCursor(Cursors.Wait);

                var sortplanVm = MainWindowVM.DisplayedVM?.VM as SortPlanViewVM;
                bool canCancel = true;
                if (sortplanVm != null)
                {
                    canCancel = sortplanVm.AskCancel();
                }

                if (canCancel)
                {
                    FrameworkElement view = null;
                    ViewBaseVM vm = null;
                    switch (viewSelection.ViewName)
                    {
                        case HOME_VIEW:
                            {
                                if (viewSelection.SubViewName == SORT_PLAN_VIEW)
                                {
                                    var homeVM = MainWindowVM.DisplayedVM?.VM as HomeViewVM;
                                    if (homeVM != null && viewSelection.Parameter == "Create")
                                    {
                                        var sortPlan = new SortPlanFileDto()
                                        {
                                            IsNew = true
                                        };
                                        view = new SortPlanView();
                                        vm = new ViewBaseVM()
                                        {
                                            VM = new SortPlanViewVM()
                                            {
                                                SortPlanFile = sortPlan,
                                                PoolTypes = homeVM?.PoolTypes
                                            }
                                        };
                                        vm.Load(MainWindowVM);
                                    }
                                    else
                                    {
                                        // Last verification is file is locked 
                                        if (homeVM?.SelectedSortPlanFile != null)
                                        {
                                            var lockFile = LockHelper.FileIsLocked(homeVM?.SelectedSortPlanFile?.FilePath + LockHelper.LOCK_FILE_EXTENSION);
                                            homeVM.SelectedSortPlanFile.IsLocked = lockFile != null;
                                            homeVM.SelectedSortPlanFile.LockedBy = lockFile?.LockedBy;
                                            if (!homeVM.SelectedSortPlanFile.IsLocked)
                                            {
                                                view = new SortPlanView();
                                                vm = new ViewBaseVM()
                                                {
                                                    VM = new SortPlanViewVM()
                                                    {
                                                        SortPlanFile = homeVM?.SelectedSortPlanFile,
                                                        PoolTypes = homeVM?.PoolTypes
                                                    }
                                                };
                                                vm.Load(MainWindowVM);
                                            }
                                            else
                                            {
                                                MessageBox.Show($"Le fichier est verrouillé par {homeVM?.SelectedSortPlanFile.LockedBy}");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Veuillez sélectionner un plan de tri");
                                        }
                                    }
                                }
                                else
                                {
                                    view = new HomeView();
                                    vm = new ViewBaseVM() { VM = new HomeViewVM() };
                                    vm.Load(MainWindowVM);
                                }
                                break;
                            }
                        case CONFIG_VIEW:
                            {
                                view = new ConfigView();
                                if (MainWindowVM.ConfigViewVM == null)
                                {
                                    MainWindowVM.ConfigViewVM = new ConfigViewVM();
                                    MainWindowVM.ConfigViewVM.Load(MainWindowVM);
                                }
                                vm = new ViewBaseVM() { VM = MainWindowVM.ConfigViewVM };
                                break;
                            }
                    }
                    if (view != null)
                    {
                        MainWindowVM.CurrentContentName = viewSelection.ViewName;
                        MainWindowVM.DisplayedVM = vm;
                        view.DataContext = vm.VM;
                        MainWindowVM.DisplayedContent = view;
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                Mouse.SetCursor(Cursors.Arrow);
            }

        }

        public static void DisplayAuthPopup(MainWindowVM mainVM)
        {
            AuthPopup p = new AuthPopup()
            {
                DataContext = mainVM
            };
            mainVM.DisplayedPopupContent = p;
            mainVM.IsPopupVisible = true;
        }

        public static void HidePopup(MainWindowVM mainVM)
        {
            mainVM.UserName = string.Empty;
            mainVM.IsPopupVisible = false;
            var authPopup = mainVM.DisplayedPopupContent as AuthPopup;
            if (authPopup != null)
            {
                authPopup.Unload();
            }
            mainVM.DisplayedPopupContent = null;
        }
    }
}
