﻿using Cesa.SortPlanEditor.Json;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Cesa.SortPlanEditor.Helpers
{
    public class LockHelper
    {
        public const string LOCK_FILE_EXTENSION = ".lock";
        public const string SP_FILE_EXTENSION = ".sp";
        public const int LOCK_FILE_INTERVAL_IN_S = 10;
        public static Task CurrentLockTask { get; set; }
        public static bool HasCurrentLock { get; set; }
        public static string CurrentLockPath { get; set; }

        public static LockFile FileIsLocked(string[] files, string searchedFile)
        {
            var existingLock = files.FirstOrDefault(c => c == searchedFile + LOCK_FILE_EXTENSION);
            var lockFile = FileIsLocked(existingLock);

            return lockFile;
        }

        public static void CreateLock(string sortPlanFilePath)
        {
            if (!string.IsNullOrEmpty(sortPlanFilePath))
            {
                HasCurrentLock = true;
                CurrentLockTask = Task.Run(() =>
                {
                    while (HasCurrentLock)
                    {
                        try
                        {
                            LockFile l = new LockFile()
                            {
                                Datetime = DateTime.Now,
                                LockedBy = RightsManager.Fullname
                            };

                            var jsonLockFile = JsonConvert.SerializeObject(l);
                            CurrentLockPath = sortPlanFilePath + LockHelper.LOCK_FILE_EXTENSION;
                            File.WriteAllText(CurrentLockPath, jsonLockFile);
                        }
                        catch (Exception)
                        {
                            // ignored
                        }

                        Thread.Sleep((LOCK_FILE_INTERVAL_IN_S/2)*1000);
                    }
                });
            }
        }

        public static void ReleaseLock()
        {
            try
            {   
                HasCurrentLock = false;
                CurrentLockTask?.Wait(1000);
                CurrentLockTask = null;
                if (!string.IsNullOrEmpty(CurrentLockPath))
                {
                    File.Delete(CurrentLockPath);
                }
                CurrentLockPath = null;
            }
            catch (Exception)
            {
                // Ignored
            }
        }

        public static LockFile FileIsLocked(string existingLock)
        {
            LockFile lockFile = null;
            try
            {
                if (existingLock != null && File.Exists(existingLock))
                {
                    //var text = File.ReadAllText(existingLock);
                    string text = null;
                    var fs = new FileStream(existingLock, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    using (var sr = new StreamReader(fs))
                    {
                        text = sr.ReadToEnd();
                    }
                    if (!string.IsNullOrEmpty(text))
                    {
                        lockFile = JsonConvert.DeserializeObject<LockFile>(text);
                        DateTime date = DateTime.MinValue;
                        if (lockFile != null)
                        {
                            var now = DateTime.Now;
                            if (lockFile.Datetime < now.AddSeconds(-LOCK_FILE_INTERVAL_IN_S))
                            {
                                File.Delete(existingLock);
                                lockFile = null;
                            }
                        }
                        else
                        {
                            File.Delete(existingLock);
                            lockFile = null;
                        }
                    }
                }
                else
                {
                    lockFile = null;
                }
            }
            catch (Exception)
            {
                // Cas où on lit un fichier locké en même temps que l'appel à WriteAllText
            }


            return lockFile;
        }
    }
}
