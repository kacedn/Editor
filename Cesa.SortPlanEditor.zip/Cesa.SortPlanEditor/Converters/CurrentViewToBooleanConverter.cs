﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Cesa.SortPlanEditor.Converters
{
    public class CurrentViewToBooleanConverter : IMultiValueConverter
    {
        public CurrentViewToBooleanConverter()
        {
        }
        
        public virtual object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            var toggleButton = values[1] as Fluent.ToggleButton;
            var commandParameter = toggleButton.CommandParameter as ViewSelection;
            bool same = values[0] is string && ((string)values[0]).Equals(commandParameter.ViewName);
            return same;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            return new object[1];
        }
    }

    public class ViewSelection 
    {
        public string ViewName { get; set; }
        public string SubViewName { get; set; }
        public string Parameter { get; set; }
    }
}
