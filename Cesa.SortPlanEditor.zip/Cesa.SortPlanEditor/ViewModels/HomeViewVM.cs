﻿using Cesa.SortPlanEditor.Dtos;
using Cesa.SortPlanEditor.Helpers;
using Cesa.SortPlanEditor.Json;
using GalaSoft.MvvmLight.Command;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace Cesa.SortPlanEditor.ViewModels
{
    public class HomeViewVM : LoadableVM
    {


        public override void Load(MainWindowVM mainVM)
        {
            PoolTypes = new ObservableCollection<PoolType>()
            {
                new PoolType() { Label = "Sortie physique", Value = "physicalOutput" },
                new PoolType() { Label = "Débordement", Value = "overflow" },
                new PoolType() { Label = "Répartition", Value = "loadBalancing" },
                new PoolType() { Label = "Dédoublement", Value = "duplication" }
            };

            LockHelper.ReleaseLock();

            if (mainVM.ConfigViewVM != null)
            {
                if (!string.IsNullOrEmpty(mainVM.ConfigViewVM.SortPlanFolder))
                {
                    SortPlans = new ObservableCollection<SortPlanFileDto>();
                    Directory.CreateDirectory(mainVM.ConfigViewVM.SortPlanFolder);
                    var files = Directory.GetFiles(mainVM.ConfigViewVM.SortPlanFolder);
                    var spFiles = files.Where(c => c.Contains(LockHelper.SP_FILE_EXTENSION) 
                    && !c.Contains(LockHelper.SP_FILE_EXTENSION+LockHelper.LOCK_FILE_EXTENSION)).ToList();
                    foreach (var file in spFiles)
                    {
                        try
                        {
                            var lockFile = LockHelper.FileIsLocked(files, file);
                            AddNewFileToList(file, lockFile);
                        }
                        catch (Exception e)
                        {
                            MessageBox.Show($"Le fichier \"{file}\" n'est pas un plan de tri valide");
                        }
                    }
                }
            }
        }

        public ObservableCollection<PoolType> PoolTypes { get; set; }

        private SortPlanFileDto _selectedSortPlanFile;
        public SortPlanFileDto SelectedSortPlanFile
        {
            get { return _selectedSortPlanFile; }
            set { _selectedSortPlanFile = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<SortPlanFileDto> _sortPlans;
        public ObservableCollection<SortPlanFileDto> SortPlans
        {
            get { return _sortPlans; }
            set { _sortPlans = value; RaisePropertyChanged(); }
        }

        private ICommand _removeSortPlanCommand;
        public ICommand RemoveSortPlanCommand
        {
            get
            {
                return _removeSortPlanCommand ?? (_removeSortPlanCommand = new RelayCommand(
                   () => {
                       if (SelectedSortPlanFile != null && !string.IsNullOrEmpty(SelectedSortPlanFile?.FilePath))
                       {
                           try
                           {
                               var r = MessageBox.Show("Voulez-vous vraiment supprimer le plan de tri selectionné ?", "Suppression", MessageBoxButton.YesNo);
                               if (r == MessageBoxResult.Yes)
                               {
                                   File.Delete(SelectedSortPlanFile?.FilePath);
                                   SortPlans.Remove(SelectedSortPlanFile);
                                   SelectedSortPlanFile = null;
                               }
                           }
                           catch (Exception e)
                           {
                               MessageBox.Show(e.ToString());
                           }
                       }
                   }));
            }
        }

        

        private void AddNewFileToList(string file, LockFile lockFile)
        {
            var text = File.ReadAllText(file);
            if (!string.IsNullOrEmpty(text))
            {
                SortPlanFile sortPlan = JsonConvert.DeserializeObject<SortPlanFile>(text);
                if (sortPlan != null)
                {
                    var dto = MapToDto(sortPlan);
                    if (dto != null)
                    {
                        dto.FilePath = file;
                        dto.IsLocked = lockFile != null;
                        dto.LockedBy = lockFile?.LockedBy;
                        SortPlans.Add(dto);
                    }
                }
            }
        }

        private SortPlanFileDto MapToDto(SortPlanFile sortPlan)
        {
            if (sortPlan == null)
                return null;

            DateTime re;
            var plan = new SortPlanFileDto()
            {
                RootSortPlan = new RootSortPlan()
                {
                    HeaderDto = new HeaderDto()
                    {
                        Alias = sortPlan?.SortPlan.Header?.Alias,
                        Created = sortPlan?.SortPlan?.Header?.Created ?? DateTime.MaxValue,
                        Label = sortPlan?.SortPlan?.Header?.Label,
                        LaunchingApproval = sortPlan?.SortPlan?.Header?.LaunchingApproval,
                        LaunchingApprovalDate = DateTime.TryParse(sortPlan?.SortPlan?.Header?.LaunchingApproval,out re) == true ? re : default(DateTime),
                        ModifiedBy = sortPlan?.SortPlan?.Header?.ModifiedBy,
                        ParcelProcessingSystemId = sortPlan?.SortPlan?.Header?.ParcelProcessingSystemId ?? -1,
                        Updated = sortPlan?.SortPlan?.Header?.Updated ?? DateTime.MaxValue,
                        Version = sortPlan?.SortPlan?.Header?.Version ?? -1,
                    }
                }
            };

            if (sortPlan?.SortPlan?.LogicalDestinationAssignments != null)
            {
                plan.RootSortPlan.LogicalDestinationOutputs = new ObservableCollection<LogicalDestinationOutputDto>();
                foreach (var log in sortPlan.SortPlan.LogicalDestinationAssignments)
                {
                    var logDto = new LogicalDestinationOutputDto()
                    {
                        Index = log.Index,
                        LogicalDestination = log.LogicalDestination,
                        LogicalOutput = log.LogicalOutput,
                        Status = log.Status == null ? new ObservableCollection<string>() : new ObservableCollection<string>(log.Status) 
                    };
                    logDto.RefreshStatusLabel();
                    plan.RootSortPlan.LogicalDestinationOutputs.Add(logDto);
                }
            }

            if (sortPlan?.SortPlan?.PhysicalRejectAssignments != null)
            {
                plan.RootSortPlan.PhysicalRejectAssignments = new ObservableCollection<PhysicalRejectAssignmentDto>();
                foreach (var log in sortPlan.SortPlan.PhysicalRejectAssignments)
                {
                    var logDto = new PhysicalRejectAssignmentDto()
                    {
                        Index = log.Index,
                        RejectLabel = log.PhysicalReject,
                        LogicalOutput = log.LogicalOutput,
                        Status = log.Status == null ? new ObservableCollection<string>() : new ObservableCollection<string>(log.Status)
                    };
                    logDto.RefreshStatusLabel();
                    plan.RootSortPlan.PhysicalRejectAssignments.Add(logDto);
                }
            }

            if (sortPlan?.SortPlan?.LogicalExitAssignments != null)
            {
                ObservableCollection<LogicalExitAssignmentDto> assignmentsDto = new ObservableCollection<LogicalExitAssignmentDto>();

                foreach (var log in sortPlan.SortPlan.LogicalExitAssignments)
                {
                    var assignmentDto = new LogicalExitAssignmentDto()
                    {
                        PhysicalOutputAssignmentDto = log.PhysicalOutputAssignments != null ? new PhysicalOutputAssignmentDto(log?.PhysicalOutputAssignments?.OutputPoolList != null ? log.PhysicalOutputAssignments.OutputPoolList.Count : 0)
                        {
                            PoolType = PoolTypes.FirstOrDefault(c => c.Value == log.PhysicalOutputAssignments.PoolType) ?? PoolTypes.FirstOrDefault(c => c.Value == "physicalOutput"),
                            PhysicalOutput = log.PhysicalOutputAssignments.PhysicalOutput,
                            IsPrefered = log.PhysicalOutputAssignments.IsPrefered,
                            PoolTypes = this.PoolTypes,
                            AllPoolTypes = this.PoolTypes,
                        } : null,
                        PhysicalOutputAssignmentDtoBinding = log.PhysicalOutputAssignments != null ? new PhysicalOutputAssignmentDto(log?.PhysicalOutputAssignments?.OutputPoolList != null ? log.PhysicalOutputAssignments.OutputPoolList.Count : 0)
                        {
                            PoolType = PoolTypes.FirstOrDefault(c => c.Value == log.PhysicalOutputAssignments.PoolType) ?? PoolTypes.FirstOrDefault(c => c.Value == "physicalOutput"),
                            PhysicalOutput = log.PhysicalOutputAssignments.PhysicalOutput,
                            IsPrefered = log.PhysicalOutputAssignments.IsPrefered,
                            PoolTypes = this.PoolTypes,
                            AllPoolTypes = this.PoolTypes,
                        } : null,
                        LogicalOutput = log.LogicalOutput,
                    };
                    assignmentsDto.Add(assignmentDto);
                    this.AssignOutputRecusively(log?.PhysicalOutputAssignments.OutputPoolList, assignmentDto.PhysicalOutputAssignmentDto.OutputPoolList, assignmentDto.PhysicalOutputAssignmentDto);
                    this.AssignOutputRecusively(log?.PhysicalOutputAssignments.OutputPoolList, assignmentDto.PhysicalOutputAssignmentDtoBinding.OutputPoolList, assignmentDto.PhysicalOutputAssignmentDtoBinding);
                    plan.RootSortPlan.LogicalExitAssignments = new ObservableCollection<LogicalExitAssignmentDto>(assignmentsDto.ToList());
                }

            }
            plan.RootSortPlan.FillPhysicalOutputLabel();
            return plan;
        }

        public void AssignOutputRecusively(List<PhysicalOutputAssignment> assignments, ObservableCollection<PhysicalOutputAssignmentDto> assignemntsDto, PhysicalOutputAssignmentDto parent = null)
        {
            if (assignments != null)
            {
                foreach (var assignment in assignments)
                {
                    var physOutput = new PhysicalOutputAssignmentDto(assignment?.OutputPoolList != null ? assignment.OutputPoolList.Count : 0)
                    {
                        PoolType = PoolTypes.FirstOrDefault(c => c.Value == assignment.PoolType) ?? PoolTypes.FirstOrDefault(c => c.Value == "physicalOutput"),
                        IsPrefered = assignment.IsPrefered,
                        PhysicalOutput = assignment.PhysicalOutput,
                        PoolTypes = this.PoolTypes,
                        AllPoolTypes = this.PoolTypes,
                        Parent = parent
                    };

                    physOutput.PoolTypes = PhysicalOutputAssignmentDto.GetFilteredPoolTypes(this.PoolTypes, parent?.PoolType);
                    assignemntsDto.Add(physOutput);
                    AssignOutputRecusively(assignment.OutputPoolList, physOutput.OutputPoolList, physOutput);
                }
            }
        }

    }
}
