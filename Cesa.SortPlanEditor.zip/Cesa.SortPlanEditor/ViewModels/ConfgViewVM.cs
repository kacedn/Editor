﻿using Cesa.SortPlanEditor.Helpers;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Cesa.SortPlanEditor.ViewModels
{
    public class ConfigViewVM : LoadableVM
    {
        public override void Load(MainWindowVM mainVM)
        {
            // Get from DB or Register
            HasChanges = false;
            MachineName = Environment.MachineName;
            string sortPlanFolder = DbHelper.GetSortPlanFolder(MachineName);

            if (string.IsNullOrEmpty(sortPlanFolder))
            {
                SortPlanFolder = "C:\\SortPlan";
                Directory.CreateDirectory(SortPlanFolder);
            }
            else
            {
                SortPlanFolder = sortPlanFolder;
            }
        }

        private bool hasChanges;
        public bool HasChanges
        {
            get { return hasChanges && RightsManager.CanWrite; }
            set { hasChanges = value; NoChanges = !value; RaisePropertyChanged(); }
        }

        private bool noChanges;
        public bool NoChanges
        {
            get { return noChanges && RightsManager.CanWrite; }
            set { noChanges = value; RaisePropertyChanged(); }
        }


        public string MachineName { get; set; }

        public string OldSortPlanFolderValue { get; set; }

        private string _sortPlanFolder;
        public string SortPlanFolder
        {
            get { return _sortPlanFolder; }
            set {
                OldSortPlanFolderValue = _sortPlanFolder;
                if (OldSortPlanFolderValue != null && value != OldSortPlanFolderValue)
                {
                    HasChanges = true;
                }
                _sortPlanFolder = value;
                RaisePropertyChanged(); }    
        }

        private ICommand _saveCommand;
        public ICommand SaveCommand
        {
            get
            {
                return _saveCommand ?? (_saveCommand = new RelayCommand(
                   () => {
                       // Register new path
                       DbHelper.SetSortPlanFolder(MachineName, SortPlanFolder);
                       MessageBox.Show("Configuration sauvegardée");
                       HasChanges = false;
                   }));
            }
        }

        private ICommand _cancelCommand;
        public ICommand CancelCommand
        {
            get
            {
                return _cancelCommand ?? (_cancelCommand = new RelayCommand(
                   () => {
                       this.Load(null);
                   }));
            }
        }

    }
}
