﻿using Cesa.SortPlanEditor.Converters;
using Cesa.SortPlanEditor.Dtos;
using Cesa.SortPlanEditor.Helpers;
using Cesa.SortPlanEditor.Json;
using Cesa.SortPlanEditor.Messages;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Cesa.SortPlanEditor.ViewModels
{
    public class SortPlanViewVM : LoadableVM
    {
        public SortPlanViewVM()
        {
            Status = new ObservableCollection<Status>();
            LogicalDestinations = new ObservableCollection<string>();
            ProcessingSystems = new ObservableCollection<ProcessingSystem>();
            RejectTypes = new ObservableCollection<RejectType>();

            HasChanges = false;
            Messenger.Default.Register<ChangeMessage>(this, (c) => HasChanges = true);
            Messenger.Default.Register<ProcessingSystemChanged>(this, (c) => Reload());
        }
        

        public MainWindowVM _mainVM { get; set; }

        public override void Unload()
        {
            Messenger.Default.Unregister<ChangeMessage>(this);
            Messenger.Default.Unregister<ProcessingSystemChanged>(this);
        }

        public void Reload()
        {
            Load(_mainVM);
        }

        public override void Load(MainWindowVM mainVM)
        {
            _mainVM = mainVM;
            CustomDestinationSelected = false;

            // Create lock file
            LockHelper.CreateLock(SortPlanFile?.FilePath);

            FillProcessingSystems();
            FillRejectTypes();
            FillLogicalDestinations(SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId);
            FillStatuses(SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId);
            FillPhysicalOutputs(SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId);
        }

        #region Listes déroulantes
        public void FillProcessingSystems()
        {
            var l = DbHelper.GetProcessingSystems();
            if (l != null)
            {
                ProcessingSystems = new ObservableCollection<ProcessingSystem>(l);
            }
        }

        public void FillRejectTypes()
        {
            var l = DbHelper.GetRejectTypes();
            if (l != null)
            {
                RejectTypes = new ObservableCollection<RejectType>(l);
                RejectTypes.Insert(0, new RejectType());
            }
        }

        public void FillLogicalDestinations(int ppsId)
        {
            var l = DbHelper.GetLogicalDestinations(ppsId);
            if (l != null)
            {
                LogicalDestinations = new ObservableCollection<string>(l);
                LogicalDestinations.Insert(0, "");
            }
        }

        public void FillPhysicalOutputs(int ppsId)
        {
            var l = DbHelper.GetPhysicalOutputs(ppsId);
            if (l != null)
            {
                PhysicalOutputs = new ObservableCollection<PhysicalOutput>(l);
            }
        }

        public void FillStatuses(int ppsId)
        {
            var l = DbHelper.GetStatusList(ppsId);
            if (l != null)
            {
                Status = new ObservableCollection<Status>(l);
            }
        }
        #endregion

        #region Outputs
        public ObservableCollection<PoolType> PoolTypes { get; set; }
        public void OnPhysicalExitTabClicked(MouseButtonEventArgs e)
        {
            // Destinations
            List<LogicalExitAssignmentDto> logicalExitAssignmentsOk = new List<LogicalExitAssignmentDto>();
            foreach (var logicalOutput in SortPlanFile.RootSortPlan.LogicalDestinationOutputs)
            {
                bool found = false;
                for (int i = 0; i < SortPlanFile.RootSortPlan.LogicalExitAssignments.Count; i++)
                {
                    var logicalExit = SortPlanFile.RootSortPlan.LogicalExitAssignments.ElementAt(i);
                    if (logicalOutput.LogicalOutput == logicalExit.LogicalOutput)
                    {
                        found = true;
                        logicalExitAssignmentsOk.Add(logicalExit);
                    }
                }
                if (!found)
                {
                    var logicalExit = new LogicalExitAssignmentDto()
                    {
                        PhysicalOutputAssignmentDto = new PhysicalOutputAssignmentDto(0)
                        {
                            PoolType = this.PoolTypes.FirstOrDefault(c => c.Value == "physicalOutput"),
                            PoolTypes = this.PoolTypes,
                            AllPoolTypes = this.PoolTypes,
                        },
                        LogicalOutput = logicalOutput.LogicalOutput,
                        PhysicalOutputAssignmentDtoBinding = new PhysicalOutputAssignmentDto()
                        {
                            PoolType = this.PoolTypes.FirstOrDefault(c => c.Value == "physicalOutput"),
                            PoolTypes = this.PoolTypes,
                            AllPoolTypes = this.PoolTypes
                        }
                    };
                    SortPlanFile.RootSortPlan.LogicalExitAssignments.Add(logicalExit);
                    logicalExitAssignmentsOk.Add(logicalExit);
                }
            }

            // Rejets
            foreach (var reject in SortPlanFile.RootSortPlan.PhysicalRejectAssignments)
            {
                bool found = false;
                for (int i = 0; i < SortPlanFile.RootSortPlan.LogicalExitAssignments.Count; i++)
                {
                    var logicalExit = SortPlanFile.RootSortPlan.LogicalExitAssignments.ElementAt(i);
                    if (reject.LogicalOutput == logicalExit.LogicalOutput)
                    {
                        found = true;
                        logicalExitAssignmentsOk.Add(logicalExit);
                    }
                }
                if (!found)
                {
                    var logicalExit = new LogicalExitAssignmentDto()
                    {
                        PhysicalOutputAssignmentDto = new PhysicalOutputAssignmentDto(0)
                        {
                            PoolType = this.PoolTypes.FirstOrDefault(c => c.Value == "physicalOutput"),
                            PoolTypes = this.PoolTypes,
                            AllPoolTypes = this.PoolTypes
                        },
                        LogicalOutput = reject.LogicalOutput,
                        PhysicalOutputAssignmentDtoBinding = new PhysicalOutputAssignmentDto()
                        {
                            PoolType = this.PoolTypes.FirstOrDefault(c => c.Value == "physicalOutput"),
                            PoolTypes = this.PoolTypes,
                            AllPoolTypes = this.PoolTypes
                        }
                    };
                    SortPlanFile.RootSortPlan.LogicalExitAssignments.Add(logicalExit);
                    logicalExitAssignmentsOk.Add(logicalExit);
                }
            }
            var distincts = SortPlanFile.RootSortPlan.LogicalExitAssignments.Except(logicalExitAssignmentsOk);
            for (int i = 0; i < distincts.Count(); i++)
            {
                SortPlanFile.RootSortPlan.LogicalExitAssignments.Remove(distincts.ElementAt(i));
            }

            SortPlanFile.RootSortPlan.FillPhysicalOutputLabel();
            
        }

        private ICommand _morePrioLogicalCommand;
        public ICommand MorePrioLogicalCommand
        {
            get
            {
                return _morePrioLogicalCommand ?? (_morePrioLogicalCommand = new RelayCommand(
                   () => {
                       if (this.SelectedLogicalDestination != null)
                       {
                           var indexof = this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.IndexOf(this.SelectedLogicalDestination);
                           var dest = this.SelectedLogicalDestination;
                           if (indexof > 0)
                           {
                               this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Remove(this.SelectedLogicalDestination);
                               this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Insert(indexof - 1, dest);
                               this.SelectedLogicalDestination = dest;
                           }
                       }
                   }));
            }
        }

        private ICommand _lessPrioLogicalCommand;
        public ICommand LessPrioLogicalCommand
        {
            get
            {
                return _lessPrioLogicalCommand ?? (_lessPrioLogicalCommand = new RelayCommand(
                   () => {
                       if (this.SelectedLogicalDestination != null)
                       {
                           var indexof = this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.IndexOf(this.SelectedLogicalDestination);
                           var dest = this.SelectedLogicalDestination;
                           if (indexof < this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Count - 1)
                           {
                               this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Remove(this.SelectedLogicalDestination);
                               this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Insert(indexof + 1, dest);
                               this.SelectedLogicalDestination = dest;
                           }
                       }
                   }));
            }
        }
        #endregion

        #region Destinations
        private LogicalDestinationOutputDto selectedLogicalDestination;
        public LogicalDestinationOutputDto SelectedLogicalDestination
        {
            get { return selectedLogicalDestination; }
            set { selectedLogicalDestination = value; RaisePropertyChanged(); }
        }

        private Status status;
        public Status SelectedStatus
        {
            get { return status; }
            set { status = value; RaisePropertyChanged(); }
        }


        private string newStatus;
        public string NewStatus
        {
            get { return newStatus; }
            set { newStatus = value; RaisePropertyChanged(); }
        }

        private bool customDestinationSelected;
        public bool CustomDestinationSelected
        {
            get { return customDestinationSelected; }
            set { customDestinationSelected = value;
                CustomDestinationEnabled = value && RightsManager.CanWrite;
                DestinationListEnabled = !value && RightsManager.CanWrite;
                RaisePropertyChanged(); }
        }


        private ObservableCollection<string> logicalDestinations;
        public ObservableCollection<string> LogicalDestinations
        {
            get { return logicalDestinations; }
            set { logicalDestinations = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<Status> _status;
        public ObservableCollection<Status> Status
        {
            get { return _status; }
            set { _status = value; RaisePropertyChanged(); }
        }

        private bool customDestinationEnabled;
        public bool CustomDestinationEnabled
        {
            get { return customDestinationEnabled; }
            set { customDestinationEnabled = value; RaisePropertyChanged(); }
        }

        private bool destinationListEnabled;
        public bool DestinationListEnabled
        {
            get { return destinationListEnabled; }
            set { destinationListEnabled = value; RaisePropertyChanged(); }
        }

        private ICommand _clearLaunchingDateCommand;
        public ICommand ClearLaunchingDateCommand
        {
            get
            {
                return _clearLaunchingDateCommand ?? (_clearLaunchingDateCommand = new RelayCommand(
                   () => {
                       SortPlanFile.RootSortPlan.HeaderDto.LaunchingApprovalDate = null;
                       HasChanges = true;
                   }));
            }
        }

        private ICommand _addLogicalOutputCommand;
        public ICommand AddLogicalOutputCommand
        {
            get
            {
                return _addLogicalOutputCommand ?? (_addLogicalOutputCommand = new RelayCommand(
                   () => {
                       SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Add(new LogicalDestinationOutputDto() { InModification = true});
                       SelectedLogicalDestination = SortPlanFile.RootSortPlan.LogicalDestinationOutputs.LastOrDefault();
                       HasChanges = true;
                   }));
            }
        }


        private ICommand _addNewStatusDestCommand;
        public ICommand AddNewStatusDestCommand
        {
            get
            {
                return _addNewStatusDestCommand ?? (_addNewStatusDestCommand = new RelayCommand(
                   () => {
                       if (!string.IsNullOrEmpty(NewStatus))
                       {
                           Status.Add(new Dtos.Status() { Label = NewStatus });
                           if (!SelectedLogicalDestination.StatusBinding.Contains(NewStatus))
                           {
                               SelectedLogicalDestination.StatusBinding.Add(NewStatus);
                               SelectedLogicalDestination.RefreshStatusLabel();
                           }
                           NewStatus = string.Empty;
                           HasChanges = true;
                       }
                   }));
            }
        }

        private ICommand _addNewStatusRejectCommand;
        public ICommand AddNewStatusRejectCommand
        {
            get
            {
                return _addNewStatusRejectCommand ?? (_addNewStatusRejectCommand = new RelayCommand(
                   () => {
                       if (!string.IsNullOrEmpty(NewStatus))
                       {
                           Status.Add(new Dtos.Status() { Label = NewStatus });
                           if (!SelectedReject.StatusBinding.Contains(NewStatus))
                           {
                               SelectedReject.StatusBinding.Add(NewStatus);
                               SelectedReject.RefreshStatusLabel();
                           }
                           NewStatus = string.Empty;
                           HasChanges = true;
                       }
                   }));
            }
        }

        private ICommand _removeLogicalOutputCommand;
        public ICommand RemoveLogicalOutputCommand
        {
            get
            {
                return _removeLogicalOutputCommand ?? (_removeLogicalOutputCommand = new RelayCommand(
                   () => {
                       if (SelectedLogicalDestination != null)
                       {
                           SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Remove(SelectedLogicalDestination);
                           HasChanges = true;
                       }
                   }));
            }
        }

        private ICommand _addStatusCommand;
        public ICommand AddStatusCommand
        {
            get
            {
                return _addStatusCommand ?? (_addStatusCommand = new RelayCommand(
                   () => {
                       if (!SelectedLogicalDestination.StatusBinding.Contains(SelectedStatus.Label))
                       {
                           SelectedLogicalDestination.StatusBinding.Add(SelectedStatus.Label);
                           SelectedLogicalDestination.RefreshStatusLabel();
                           HasChanges = true;
                       }
                   }));
            }
        }

        private ICommand _addAllStatusCommand;
        public ICommand AddAllStatusCommand
        {
            get
            {
                return _addAllStatusCommand ?? (_addAllStatusCommand = new RelayCommand(
                   () => {
                       SelectedLogicalDestination.StatusBinding.Clear();
                       foreach(var s in Status)
                       {
                           SelectedLogicalDestination.StatusBinding.Add(s.Label);
                       }
                       SelectedLogicalDestination.RefreshStatusLabel();
                       HasChanges = true;
                   }));
            }
        }

        private ICommand _removeStatusCommand;
        public ICommand RemoveStatusCommand
        {
            get
            {
                return _removeStatusCommand ?? (_removeStatusCommand = new RelayCommand(
                   () => {
                       SelectedLogicalDestination.StatusBinding.Remove(SelectedLogicalDestination.SelectedStatus);
                       SelectedLogicalDestination.RefreshStatusLabel();
                       HasChanges = true;
                   }));
            }
        }

        private ICommand _removeAllStatusCommand;
        public ICommand RemoveAllStatusCommand
        {
            get
            {
                return _removeAllStatusCommand ?? (_removeAllStatusCommand = new RelayCommand(
                   () => {
                       SelectedLogicalDestination.StatusBinding.Clear();
                       SelectedLogicalDestination.RefreshStatusLabel();
                       HasChanges = true;
                   }));
            }
        }
        #endregion

        #region Rejects
        private PhysicalRejectAssignmentDto selectedReject;
        public PhysicalRejectAssignmentDto SelectedReject
        {
            get { return selectedReject; }
            set { selectedReject = value;
                if (value != null)
                {
                    value.RejectType = RejectTypes.FirstOrDefault(c => c.SortPlanLabel == value.RejectLabel);
                }
                RaisePropertyChanged(); }
        }

        private ICommand _morePrioRejectCommand;
        public ICommand MorePrioRejectCommand
        {
            get
            {
                return _morePrioRejectCommand ?? (_morePrioRejectCommand = new RelayCommand(
                   () => {
                       if(this.SelectedReject != null)
                       {
                           var indexof = this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.IndexOf(this.SelectedReject);
                           var reject = this.SelectedReject;
                           if (indexof > 0)
                           {
                               this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Remove(this.SelectedReject);
                               this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Insert(indexof - 1, reject);
                               this.SelectedReject = reject;
                               HasChanges = true;
                           }
                       }
                   }));
            }
        }

        private ICommand _lessPrioRejectCommand;
        public ICommand LessPrioRejectCommand
        {
            get
            {
                return _lessPrioRejectCommand ?? (_lessPrioRejectCommand = new RelayCommand(
                   () => {
                       if (this.SelectedReject != null)
                       {
                           var indexof = this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.IndexOf(this.SelectedReject);
                           var reject = this.SelectedReject;
                           if (indexof < this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Count-1)
                           {
                               this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Remove(this.SelectedReject);
                               this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Insert(indexof + 1, reject);
                               this.SelectedReject = reject;
                               HasChanges = true;
                           }
                       }
                   }));
            }
        }

        private ICommand _addRejectCommand;
        public ICommand AddRejectCommand
        {
            get
            {
                return _addRejectCommand ?? (_addRejectCommand = new RelayCommand(
                   () => {
                       SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Add(new PhysicalRejectAssignmentDto() { InModification = true});
                       SelectedReject = SortPlanFile.RootSortPlan.PhysicalRejectAssignments.LastOrDefault();
                       HasChanges = true;
                   }));
            }
        }

        private ICommand _removeRejectCommand;
        public ICommand RemoveRejectCommand
        {
            get
            {
                return _removeRejectCommand ?? (_removeRejectCommand = new RelayCommand(
                   () => {
                       if (SelectedReject != null)
                       {
                           SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Remove(SelectedReject);
                       }
                       HasChanges = true;
                   }));
            }
        }

        private ICommand _addStatusInRejectCommand;
        public ICommand AddStatusInRejectCommand
        {
            get
            {
                return _addStatusInRejectCommand ?? (_addStatusInRejectCommand = new RelayCommand(
                   () => {
                       if (!SelectedReject.StatusBinding.Contains(SelectedStatus.Label))
                       {
                           SelectedReject.StatusBinding.Add(SelectedStatus.Label);
                           SelectedReject.RefreshStatusLabel();
                           HasChanges = true;
                       }
                   }));
            }
        }

        private ICommand _addAllStatusInRejectCommand;
        public ICommand AddAllStatusInRejectCommand
        {
            get
            {
                return _addAllStatusInRejectCommand ?? (_addAllStatusInRejectCommand = new RelayCommand(
                   () => {
                       SelectedReject.StatusBinding.Clear();
                       foreach (var s in Status)
                       {
                           SelectedReject.StatusBinding.Add(s.Label);
                       }
                       SelectedReject.RefreshStatusLabel();
                       HasChanges = true;
                   }));
            }
        }

        private ICommand _removeStatusInRejectCommand;
        public ICommand RemoveStatusInRejectCommand
        {
            get
            {
                return _removeStatusInRejectCommand ?? (_removeStatusInRejectCommand = new RelayCommand(
                   () => {
                       SelectedReject.StatusBinding.Remove(SelectedReject.SelectedStatus);
                       SelectedReject.RefreshStatusLabel();
                       HasChanges = true;
                   }));
            }
        }

        private ICommand _removeAllStatusInRejectCommand;
        public ICommand RemoveAllStatusInRejectCommand
        {
            get
            {
                return _removeAllStatusInRejectCommand ?? (_removeAllStatusInRejectCommand = new RelayCommand(
                   () => {
                       SelectedReject.StatusBinding.Clear();
                       SelectedReject.RefreshStatusLabel();
                       HasChanges = true;
                   }));
            }
        }
        #endregion

        private ObservableCollection<ProcessingSystem> processingSystems;
        public ObservableCollection<ProcessingSystem> ProcessingSystems
        {
            get { return processingSystems; }
            set { processingSystems = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<PhysicalOutput> physicalOutputs;
        public ObservableCollection<PhysicalOutput> PhysicalOutputs
        {
            get { return physicalOutputs; }
            set { physicalOutputs = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<RejectType> rejectTypes;
        public ObservableCollection<RejectType> RejectTypes
        {
            get { return rejectTypes; }
            set { rejectTypes = value; RaisePropertyChanged(); }
        }

        private ObservableCollection<LogicalOutputDto> logicalOutputs;
        public ObservableCollection<LogicalOutputDto> LogicalOutputs
        {
            get { return logicalOutputs; }
            set { logicalOutputs = value; RaisePropertyChanged(); }
        }

        public SortPlanFileDto SortPlanFile { get; set; }

        private ICommand _cancelCommand;
        public ICommand CancelCommand
        {
            get
            {
                return _cancelCommand ?? (_cancelCommand = new RelayCommand(
                   () => {
                       Cancel();
                   }));
            }
        }

        private bool hasChanges;
        public bool HasChanges
        {
            get { return hasChanges; }
            set
            {
                hasChanges = value;
                if (HasChanges)
                {
                    SaveEnabled = true;
                    CancelLabel = "Annuler";
                }
                else
                {
                    SaveEnabled = false;
                    CancelLabel = "Fermer";
                }
                RaisePropertyChanged();
            }
        }

        private bool saveEnabled;
        public bool SaveEnabled
        {
            get { return saveEnabled && RightsManager.CanWrite; }
            set { saveEnabled = value;  RaisePropertyChanged(); }
        }


        private string cancelLabel;
        public string CancelLabel
        {
            get { return cancelLabel; }
            set { cancelLabel = value; RaisePropertyChanged(); }
        }

        public bool AskCancel()
        {
            bool result = true;
            if (MessageBox.Show("Voulez-vous annuler l'édition du plan de tri ?", "Annulation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public void Cancel()
        {
            if (HasChanges)
            {
                if (AskCancel())
                {
                    Unload();
                    _mainVM.ExecuteNavigate(new ViewSelection() { ViewName = NavigationHelper.HOME_VIEW });
                    HasChanges = false;
                }
            }
            else
            {
                Unload();
                _mainVM.ExecuteNavigate(new ViewSelection() { ViewName = NavigationHelper.HOME_VIEW });
                HasChanges = false;
            }
            
        }

        private ICommand _incrementVersionCommand;
        public ICommand IncrementVersionCommand
        {
            get
            {
                return _incrementVersionCommand ?? (_incrementVersionCommand = new RelayCommand(
                   () => {
                       SortPlanFile.RootSortPlan.HeaderDto.Version++;
                       HasChanges = true;
                   }));
            }
        }

        

        private ICommand _decrementVersionCommand;
        public ICommand DecrementVersionCommand
        {
            get
            {
                return _decrementVersionCommand ?? (_decrementVersionCommand = new RelayCommand(
                   () => {
                       SortPlanFile.RootSortPlan.HeaderDto.Version--;
                       HasChanges = true;
                   }));
            }
        }


        private ICommand _saveCommand;
        public ICommand SaveCommand
        {
            get
            {
                return _saveCommand ?? (_saveCommand = new RelayCommand(
                   () => {
                       Save();
                   }));
            }
        }

        private ICommand _saveAsCommand;
        public ICommand SaveAsCommand
        {
            get
            {
                return _saveAsCommand ?? (_saveAsCommand = new RelayCommand(
                   () => {
                       SaveAs();
                   }));
            }
        }

        private void Save()
        {
            try
            {
                string errors = GetErrors();
                if (string.IsNullOrEmpty(errors))
                {
                    string json = GetJson();
                    File.WriteAllText(this.SortPlanFile.FilePath, json);
                    MessageBox.Show("Le plan de tri est sauvegardé");
                    HasChanges = false;
                }
                else
                {
                    MessageBox.Show("Le plan de tri n'a pas été sauvegardé");
                }
            }
            catch (Exception e) 
            {
                MessageBox.Show(e.ToString());
            }
        }

        private string GetJson()
        {
            this.SortPlanFile.RootSortPlan.HeaderDto.ModifiedBy = RightsManager.Fullname;
            this.SortPlanFile.RootSortPlan.HeaderDto.Updated = DateTime.Now;
            this.SortPlanFile.RootSortPlan.FillPhysicalOutputLabel();
            var obj = MapToObject(this.SortPlanFile);
            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                DefaultValueHandling = DefaultValueHandling.Ignore,
                DateFormatHandling = DateFormatHandling.IsoDateFormat,
                DateTimeZoneHandling = DateTimeZoneHandling.Utc
            };
            IsoDateTimeConverter dateConverter = new IsoDateTimeConverter
            {
                DateTimeFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'"
            };
            settings.Converters.Add(dateConverter);
            string json = JsonConvert.SerializeObject(obj,
                    Newtonsoft.Json.Formatting.Indented,
                    settings
                    );
            return json;
        }

        private string GetErrors()
        {
            string errors = null;
            // Vérifs
            for (int i = 0; i < this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Count; i++)
            {
                var dest = this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.ElementAt(i);
                dest.Index = i;
                if (string.IsNullOrEmpty(dest.LogicalDestination) && !dest.Status.Any())
                {
                    errors = $"- Au moins une sortie logique ne possède pas de destination ni de statuts\n";
                }
            }
            for (int i = 0; i < this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.Count; i++)
            {
                var reject = this.SortPlanFile.RootSortPlan.PhysicalRejectAssignments.ElementAt(i);
                reject.Index = i;
                if (string.IsNullOrEmpty(reject.RejectLabel))
                {
                    errors = $"- Un rejet défini ne possède par de type de rejet\n";
                }
            }

            if (this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Select(c => c.LogicalOutput).Distinct().Count() != 
                this.SortPlanFile.RootSortPlan.LogicalDestinationOutputs.Select(c => c.LogicalOutput).Count())
            {
                errors = $"- Il existe des doublons de sorties logique\n";
            }

            if (!string.IsNullOrEmpty(errors))
            {
                MessageBox.Show(errors);
            }
            return errors;
        }

        public void OnProcessingSystemSelectionChanged(SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                var newProcessingSystem = e.AddedItems?[0] as ProcessingSystem;
                if (newProcessingSystem != null)
                {
                    if (newProcessingSystem.Id != SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId)
                    {
                        if (MessageBox.Show("Le changement de système de tri réinitialise l'affectation des sorties, voulez-vous poursuivre ?", "Changement", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                        {
                            SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId = newProcessingSystem.Id;
                            FillRejectTypes();
                            FillLogicalDestinations(SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId);
                            FillStatuses(SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId);
                            FillPhysicalOutputs(SortPlanFile.RootSortPlan.HeaderDto.ParcelProcessingSystemId);
                        }
                    }
                }
            }
        }

        private void SaveAs()
        {
            try
            {
                string errors = GetErrors();
                if (string.IsNullOrEmpty(errors))
                {

                    string json = GetJson();
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.DefaultExt = "sp";
                    saveFileDialog.Filter = "Plans de tri|*.sp";
                    saveFileDialog.InitialDirectory = _mainVM?.ConfigViewVM?.SortPlanFolder;
                    if (saveFileDialog.ShowDialog() == true)
                    {
                        if (!this.SortPlanFile.IsNew)
                        {
                            LockHelper.ReleaseLock();
                        }
                        File.WriteAllText(saveFileDialog.FileName, json);
                        this.SortPlanFile.IsNew = false;
                        this.SortPlanFile.FilePath = saveFileDialog.FileName;
                        LockHelper.CreateLock(SortPlanFile?.FilePath);
                        MessageBox.Show("Le plan de tri est sauvegardé");
                        HasChanges = false;
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private SortPlanFile MapToObject(SortPlanFileDto sortPlan)
        {
            if (sortPlan == null)
                return null;

            var plan = new SortPlanFile()
            {
                SortPlan = new SortPlan()
                {
                    Header = new Header()
                    {
                        Alias = sortPlan?.RootSortPlan?.HeaderDto?.Alias,
                        Created = sortPlan?.RootSortPlan?.HeaderDto?.Created ?? DateTime.MaxValue,
                        Label = sortPlan?.RootSortPlan?.HeaderDto?.Label,
                        LaunchingApproval = sortPlan?.RootSortPlan?.HeaderDto?.LaunchingApproval,
                        ModifiedBy = sortPlan?.RootSortPlan?.HeaderDto?.ModifiedBy,
                        ParcelProcessingSystemId = sortPlan?.RootSortPlan?.HeaderDto?.ParcelProcessingSystemId ?? -1,
                        Updated = sortPlan?.RootSortPlan?.HeaderDto?.Updated,
                        Version = sortPlan?.RootSortPlan?.HeaderDto?.Version ?? -1,
                    },
                    LogicalDestinationAssignments = (from d in sortPlan?.RootSortPlan?.LogicalDestinationOutputs
                                                     select new LogicalDestinationAssignment()
                                                     {
                                                         Index = d.Index,
                                                         LogicalDestination = d.LogicalDestination,
                                                         LogicalOutput = d.LogicalOutput,
                                                         Status = new List<string>(d.Status.ToList())
                                                     }).ToList(),
                    PhysicalRejectAssignments = (from d in sortPlan?.RootSortPlan?.PhysicalRejectAssignments
                                                 select new PhysicalRejectAssignment()
                                                 {
                                                     Index = d.Index,
                                                     PhysicalReject = d.RejectLabel,
                                                     LogicalOutput = d.LogicalOutput,
                                                     Status = new List<string>(d.Status.ToList())
                                                 }).ToList()
                }
            };

            if (sortPlan?.RootSortPlan?.LogicalExitAssignments != null)
            {
                ObservableCollection<LogicalExitAssignment> assignments = new ObservableCollection<LogicalExitAssignment>();

                foreach (var log in sortPlan.RootSortPlan.LogicalExitAssignments)
                {
                    var assignment = new LogicalExitAssignment()
                    {
                        PhysicalOutputAssignments = log.PhysicalOutputAssignmentDto != null ? new PhysicalOutputAssignment()
                        {
                            PoolType = log.PhysicalOutputAssignmentDto.PoolType?.Value,
                            PhysicalOutput = log.PhysicalOutputAssignmentDto.PhysicalOutput,
                            IsPrefered = log.PhysicalOutputAssignmentDto.IsPrefered
                        } : null,
                        LogicalOutput = log.LogicalOutput,
                    };
                    assignments.Add(assignment);

                    this.AssignOutputRecusively(log?.PhysicalOutputAssignmentDto.OutputPoolList, assignment.PhysicalOutputAssignments.OutputPoolList);
                    plan.SortPlan.LogicalExitAssignments = assignments.ToList();
                }
            }
            return plan;
        }

        public void AssignOutputRecusively(ObservableCollection<PhysicalOutputAssignmentDto> assignmentsDto, List<PhysicalOutputAssignment> assignemnts)
        {
            if (assignmentsDto != null)
            {
                foreach (var assignment in assignmentsDto)
                {
                    var physOutput = new PhysicalOutputAssignment()
                    {
                        PoolType = assignment.PoolType?.Value,
                        IsPrefered = assignment.IsPrefered,
                        PhysicalOutput = assignment.PhysicalOutput,
                    };
                    assignemnts.Add(physOutput);
                    AssignOutputRecusively(assignment.OutputPoolList, physOutput.OutputPoolList);
                }
            }
        }

    }
}
